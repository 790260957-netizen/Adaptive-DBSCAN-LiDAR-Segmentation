"""
v13 + 两步实例融合
==================
DBSCAN → 贪心合并 → PCA过滤 → 去小簇
"""
import numpy as np
from sklearn.cluster import DBSCAN
from sklearn.neighbors import NearestNeighbors
from scipy.spatial import cKDTree


def _greedy_merge(points, labels, merge_dist=1.0, max_merge_dist=2.5):
    labels = labels.copy()
    ct = merge_dist
    while ct <= max_merge_dist:
        uids = np.unique(labels[labels >= 0])
        if len(uids) <= 1: break
        centroids = np.array([points[labels == u].mean(axis=0) for u in uids])
        pairs = cKDTree(centroids).query_pairs(ct, output_type='ndarray')
        if len(pairs) == 0:
            ct += 0.5; continue
        parent = {u: u for u in uids}
        def find(x):
            while parent[x] != x:
                parent[x] = parent[parent[x]]
                x = parent[x]
            return x
        def union(a, b):
            ra, rb = find(a), find(b)
            if ra != rb: parent[rb] = ra
        for i, j in pairs: union(uids[i], uids[j])
        root = {}
        for u in uids:
            r = find(u)
            if r not in root: root[r] = len(root)
            labels[labels == u] = root[r]
        ct += 0.5
    valid = labels >= 0
    if np.any(valid):
        _, labels[valid] = np.unique(labels[valid], return_inverse=True)
    return labels


def _filter_background(points, labels, planarity_thr=0.75, linearity_thr=0.95):
    """PCA 物理过滤: 删墙/杆/矮"""
    labels = labels.copy()
    for uid in np.unique(labels[labels >= 0]):
        mask = labels == uid
        pts = points[mask]
        n = len(pts)
        if n < 5: labels[mask] = -1; continue

        z_span = pts[:, 2].max() - pts[:, 2].min()
        if z_span < 0.3: labels[mask] = -1; continue
        if z_span > 1.5 and n < 50: labels[mask] = -1; continue

        centered = pts - pts.mean(axis=0)
        eig = np.sort(np.linalg.eigh(centered.T @ centered / (n-1))[0])[::-1]
        esum = eig.sum() + 1e-10
        l1, l2, l3 = eig / esum
        planarity = (l2 - l3) / (l1 + 1e-10)
        linearity = (l1 - l2) / (l1 + 1e-10)

        if planarity > planarity_thr: labels[mask] = -1
        elif linearity > linearity_thr: labels[mask] = -1

    valid = labels >= 0
    if np.any(valid):
        _, labels[valid] = np.unique(labels[valid], return_inverse=True)
    return labels, len(np.unique(labels[labels >= 0]))


def _adaptive_eps_from_knee(feats, min_samples=10, sensitivity=1.0):
    k = min_samples - 1
    if k < 1 or feats.shape[0] <= k + 1: return 0.5
    nn = NearestNeighbors(n_neighbors=k + 1, n_jobs=-1).fit(feats)
    distances, _ = nn.kneighbors(feats)
    k_dist = np.sort(distances[:, k]); k_dist = k_dist[k_dist > 0]
    if len(k_dist) < 5: return float(np.median(k_dist))
    x = np.arange(len(k_dist)) / (len(k_dist) - 1)
    y = (k_dist - k_dist[0]) / (k_dist[-1] - k_dist[0] + 1e-10)
    return max(float(k_dist[int(np.argmax(np.abs(y - x)))]) * sensitivity, 0.05)


def ipdbscan_adaptive_xyz(points, sensitivity=2.0, min_samples=10,
                           merge_dist=1.0, max_merge_dist=3.0,
                           min_cluster_size=20,
                           intensity=None, intensity_weight=0.0,
                           **kwargs):
    """
    v13: DBSCAN → merge → PCA过滤 → 去小簇
    """
    n = len(points)
    if n < min_samples:
        return np.full(n, -1, dtype=int), 0.0

    feats = points.astype(np.float64)
    if intensity is not None and intensity_weight > 0:
        ints = intensity.reshape(-1) if intensity.ndim > 1 else intensity
        feats = np.column_stack([feats, ints * intensity_weight])

    eps = _adaptive_eps_from_knee(feats, min_samples=min_samples,
                                   sensitivity=sensitivity)
    labels = DBSCAN(eps=eps, min_samples=min_samples, n_jobs=-1).fit_predict(feats)
    n1 = len(np.unique(labels[labels >= 0]))

    if n1 > 1:
        labels = _greedy_merge(points, labels, merge_dist=merge_dist,
                                max_merge_dist=max_merge_dist)

    labels, n2 = _filter_background(points, labels)

    uids, counts = np.unique(labels[labels >= 0], return_counts=True)
    for u in uids[counts < min_cluster_size]:
        labels[labels == u] = -1
    valid = labels >= 0
    if np.any(valid):
        _, labels[valid] = np.unique(labels[valid], return_inverse=True)

    n_final = len(np.unique(labels[labels >= 0]))
    n_clust = int(np.sum(labels != -1))
    print(f"  [v13] eps={eps:.3f} "
          f"dbscan→{n1}c pca→{n2}c →{n_final}c "
          f"({n_clust}/{n} pts)")

    return labels, eps
