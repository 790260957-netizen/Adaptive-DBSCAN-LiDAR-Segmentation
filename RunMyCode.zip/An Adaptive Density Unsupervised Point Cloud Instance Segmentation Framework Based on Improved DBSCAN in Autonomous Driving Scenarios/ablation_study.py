﻿"""
消融实验 — IPDBSCAN v13 组件贡献分析 (加法消融, 含逐类 mIoU)
==========================================================
从最简 baseline (Raw DBSCAN) 开始，逐步叠加组件，与 main.py 流水线完全一致。

加法链 (5 模块):
  Raw DBSCAN → +Ground → +AdaptiveEPS(+Intensity) → +Merge → +PCA (= Full v13)

对应 main.py:
  load_kitti_bin → remove_ground_grid
    → adaptive_eps(k-NN knee) + DBSCAN(xyz + intensity×iw)
    → greedy_merge(1.0→3.0m) → PCA filter → 去小簇

每个变体只在上一个变体基础上增加一个组件，参数全部从 config.yaml 读取。

输出: plots/ablation/ 下图表 + CSV
"""

import os, sys, time, warnings
import numpy as np, pandas as pd
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy.spatial import cKDTree
from scipy.optimize import linear_sum_assignment
from sklearn.cluster import DBSCAN
from tqdm import tqdm

warnings.filterwarnings("ignore")

from core.preprocess     import load_kitti_bin, remove_ground_grid
from core.ipdbscan_fusion import (_greedy_merge, _filter_background,
                                   _adaptive_eps_from_knee)
from utils.metrics       import compute_metrics

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
PLOT_DIR   = os.path.join(SCRIPT_DIR, "plots", "ablation")
os.makedirs(PLOT_DIR, exist_ok=True)

THING_CLASSES = {1: "Car", 2: "Bicycle", 3: "Motorcycle", 4: "Truck",
                 5: "Other-Veh.", 6: "Person", 7: "Bicyclist", 8: "Motorcyclist"}
CLASS_NAMES = list(THING_CLASSES.values())


# ═══════════════════════════════════════════════════════════════
# 标签编码检测 (与 main.py / per_class_miou.py 完全一致)
# ═══════════════════════════════════════════════════════════════

_ENCODING_DETECTED = None

def detect_label_encoding(lbl_path):
    global _ENCODING_DETECTED
    if _ENCODING_DETECTED is not None:
        return _ENCODING_DETECTED
    lbl = np.fromfile(lbl_path, dtype=np.uint32)
    hi16, lo16 = lbl >> 16, lbl & 0xFFFF
    hi_ratio = np.mean((hi16[hi16 > 0] >= 0) & (hi16[hi16 > 0] <= 30)) if (hi16 > 0).any() else 0
    lo_ratio = np.mean((lo16[lo16 > 0] >= 0) & (lo16[lo16 > 0] <= 30)) if (lo16 > 0).any() else 0
    _ENCODING_DETECTED = "A" if lo_ratio > hi_ratio else "B"
    return _ENCODING_DETECTED


def extract_labels(lbl_raw):
    if _ENCODING_DETECTED == "B":
        return (lbl_raw >> 16).astype(np.int32), (lbl_raw & 0xFFFF).astype(np.int32)
    return (lbl_raw & 0xFFFF).astype(np.int32), (lbl_raw >> 16).astype(np.int32)


# ═══════════════════════════════════════════════════════════════
# Per-Class mIoU
# ═══════════════════════════════════════════════════════════════

def per_class_miou_one_frame(labels_pred, labels_gt_aligned,
                              gt_inst_full, gt_sem_full, debug=False):
    unique_pred = np.unique(labels_pred[labels_pred >= 0])
    unique_true_full = np.unique(gt_inst_full[gt_inst_full > 0])
    unique_true_aligned = np.unique(labels_gt_aligned[labels_gt_aligned > 0])

    result = {cn: np.nan for cn in CLASS_NAMES}
    if len(unique_pred) == 0 or len(unique_true_full) == 0:
        return result

    gt_cls_map = {}
    for tid in unique_true_full:
        mask = gt_inst_full == tid
        s = gt_sem_full[mask]
        if len(s) == 0:
            gt_cls_map[tid] = -1
            continue
        us, cs = np.unique(s, return_counts=True)
        gt_cls_map[tid] = int(us[np.argmax(cs)])

    pred_cls_map = {}
    for pid in unique_pred:
        mask = labels_pred == pid
        g = labels_gt_aligned[mask]
        g = g[g > 0]
        if len(g) == 0:
            pred_cls_map[pid] = -1
            continue
        ug, cg = np.unique(g, return_counts=True)
        pred_cls_map[pid] = gt_cls_map.get(int(ug[np.argmax(cg)]), -1)

    for cls_id, cls_name in THING_CLASSES.items():
        gt_of_class = [t for t in unique_true_aligned
                       if gt_cls_map.get(t, -1) == cls_id]
        pred_of_class = [p for p in unique_pred
                         if pred_cls_map.get(p, -1) == cls_id]
        n_pr, n_gt = len(pred_of_class), len(gt_of_class)
        if n_pr == 0 or n_gt == 0:
            continue
        masks_p = [labels_pred == pid for pid in pred_of_class]
        masks_t = [labels_gt_aligned == tid for tid in gt_of_class]
        iou_mat = np.zeros((n_pr, n_gt))
        for pi in range(n_pr):
            for ti in range(n_gt):
                inter = np.sum(masks_p[pi] & masks_t[ti])
                union = np.sum(masks_p[pi] | masks_t[ti])
                if union > 0:
                    iou_mat[pi, ti] = inter / union
        if n_pr <= n_gt:
            best_iou = iou_mat.max(axis=1)
        else:
            row_idx, col_idx = linear_sum_assignment(-iou_mat)
            best_iou = iou_mat[row_idx, col_idx]
        if len(best_iou) > 0:
            result[cls_name] = float(np.mean(best_iou))
    return result


# ═══════════════════════════════════════════════════════════════
# 消融版聚类 — 与 ipdbscan_adaptive_xyz 逻辑完全一致，只增加开关
# ═══════════════════════════════════════════════════════════════

def ipdbscan_ablated(points, *,
                     use_adaptive_eps=True,
                     use_merge=False,
                     use_pca_filter=True,
                     eps_base=0.62,
                     min_samples=8,
                     sensitivity=2.23,
                     min_cluster_size=13,
                     intensity_weight=0.0,
                     intensity_arr=None):
    """
    与 ipdbscan_adaptive_xyz 流水线逐行对齐:
      adaptive_eps → DBSCAN → merge → PCA → 去小簇

    参数:
      use_adaptive_eps  : True=k-NN knee自适应eps + intensity特征 (=main.py DBSCAN阶段)
                          False=固定eps_base + 纯xyz特征
      use_merge         : True=贪心合并 (1.0→3.0m)
      use_pca_filter    : True=PCA几何过滤 (删墙/杆/球/矮)
    """
    n = len(points)
    if n < min_samples:
        return np.full(n, -1, dtype=int)

    # --- 特征构建 (与 ipdbscan_adaptive_xyz 一致) ---
    feats = points[:, :3].astype(np.float64)
    if use_adaptive_eps and intensity_arr is not None and intensity_weight > 0:
        # +AdaptiveEPS 步骤同时开启 intensity 特征 (= main.py 的 DBSCAN 阶段)
        ints = intensity_arr.ravel() if intensity_arr.ndim > 1 else intensity_arr
        feats = np.column_stack([feats, ints * intensity_weight])

    # --- Adaptive EPS (与 _adaptive_eps_from_knee 一致) ---
    if use_adaptive_eps:
        eps = _adaptive_eps_from_knee(feats, min_samples=min_samples,
                                       sensitivity=sensitivity)
    else:
        eps = eps_base

    # --- DBSCAN ---
    labels = DBSCAN(eps=eps, min_samples=min_samples, n_jobs=-1).fit_predict(feats)
    n1 = len(np.unique(labels[labels >= 0]))

    # --- 贪心合并: 修复 DBSCAN 过分割碎片 (1.0→3.0m) ---
    if use_merge and n1 > 1:
        labels = _greedy_merge(points, labels, merge_dist=1.0, max_merge_dist=3.0)

    # --- PCA 几何过滤: 删墙/杆/球/矮 ---
    if use_pca_filter:
        labels, n2 = _filter_background(points, labels)
    else:
        n2 = len(np.unique(labels[labels >= 0]))

    # --- 去小簇 (< min_cluster_size, 与 main.py 一致) ---
    uids, counts = np.unique(labels[labels >= 0], return_counts=True)
    for u in uids[counts < min_cluster_size]:
        labels[labels == u] = -1

    # --- 重新编号 (与 main.py 一致) ---
    valid = labels >= 0
    if np.any(valid):
        _, labels[valid] = np.unique(labels[valid], return_inverse=True)

    return labels


# ═══════════════════════════════════════════════════════════════
# 加法消融变体定义 (5 模块)
# 每个变体只在上一个基础上增加一个结构性组件
# ═══════════════════════════════════════════════════════════════

ABLATIONS = [
    # [1] 最简 baseline: 无地面去除、固定eps、纯xyz、无合并、无PCA
    {"name": "Raw DBSCAN", "short": "RawDBSCAN",
     "skip_ground": True,
     "use_adaptive_eps": False, "use_merge": False,
     "use_pca_filter": False,
     "color": "#B0B0B0"},

    # [2] + 网格去地面 (与 main.py remove_ground_grid 一致)
    {"name": "+ Ground Removal", "short": "+Ground",
     "use_adaptive_eps": False, "use_merge": False,
     "use_pca_filter": False,
     "color": "#F4A460"},

    # [3] + Adaptive EPS & Intensity (= main.py 的 DBSCAN 阶段)
    #     同时启用 k-NN knee 自适应 eps + intensity 特征增强
    {"name": "+ Adaptive EPS", "short": "+AdaptEPS",
     "use_adaptive_eps": True, "use_merge": False,
     "use_pca_filter": False,
     "color": "#5DADE2"},

    # [4] + Greedy Merge (1.0→3.0m): 修复 DBSCAN 过分割碎片
    {"name": "+ Greedy Merge", "short": "+Merge",
     "use_adaptive_eps": True, "use_merge": True,
     "use_pca_filter": False,
     "color": "#85C1E9"},

    # [5] + PCA Filter: 几何过滤 (删墙/杆/球/矮)
    #     = Full v13 = main.py ipdbscan_adaptive_xyz 完整流水线
    {"name": "+ PCA Filter [Full]", "short": "+PCA",
     "use_adaptive_eps": True, "use_merge": True,
     "use_pca_filter": True,
     "color": "#2ECC40"},
]


# ═══════════════════════════════════════════════════════════════
# 单帧评估
# ═══════════════════════════════════════════════════════════════

def run_frame(bin_path, lbl_path, ablate_cfg, params, pc_raw=None, debug=False):
    """对单帧运行消融变体并返回指标。"""
    if pc_raw is None:
        pc_raw = load_kitti_bin(bin_path)

    # --- 预处理: 去地面 ---
    gt = params["ground_dist_threshold"]
    ground_thresh = -100.0 if ablate_cfg.get("skip_ground") else gt
    pts, imat = remove_ground_grid(pc_raw, voxel_size=params["voxel_size"],
                                      ground_z_thresh=ground_thresh)
    ints = imat.ravel() if len(imat) > 0 else None
    if pts.shape[0] < 10:
        return None

    t0 = time.perf_counter()

    labels_pred = ipdbscan_ablated(
        pts,
        use_adaptive_eps=ablate_cfg["use_adaptive_eps"],
        use_merge=ablate_cfg["use_merge"],
        use_pca_filter=ablate_cfg["use_pca_filter"],
        eps_base=params["eps_base"],
        min_samples=params["min_samples"],
        sensitivity=params["sensitivity"],
        min_cluster_size=params["min_cluster_size"],
        intensity_weight=params["intensity_weight"],
        intensity_arr=ints,
    )

    t1 = time.perf_counter()

    # --- 标签对齐与评估 (与 main.py 完全一致) ---
    lbl_raw = np.fromfile(lbl_path, dtype=np.uint32)

    # compute_metrics: >>16 编码
    gt_inst_main = (lbl_raw >> 16).astype(np.int32)
    tree_gt = cKDTree(pc_raw[:, :3])
    _, n_idx = tree_gt.query(pts, k=1)
    gt_aligned_main = gt_inst_main[n_idx]
    if np.sum(gt_aligned_main > 0) < 10:
        return None
    m = compute_metrics(pts, labels_pred, gt_aligned_main)

    # per_class_miou: extract_labels
    gt_sem_full, gt_inst_full = extract_labels(lbl_raw)
    gt_inst_aligned_pc = gt_inst_full[n_idx]
    pc = per_class_miou_one_frame(labels_pred, gt_inst_aligned_pc,
                                   gt_inst_full, gt_sem_full, debug=debug)

    n_pred_inst = len(np.unique(labels_pred[labels_pred >= 0]))
    n_gt_inst   = len(np.unique(gt_inst_aligned_pc[gt_inst_aligned_pc > 0]))
    n_pts_used  = pts.shape[0]
    n_clustered = int(np.sum(labels_pred >= 0))

    if debug:
        print(f"    pts={n_pts_used} | pred_inst={n_pred_inst} gt_inst={n_gt_inst} "
              f"| clustered={n_clustered} ({100*n_clustered/n_pts_used:.0f}%)")

    return {"F1": m["F1_Score"], "Precision": m["Precision"],
            "Recall": m["Recall"], "AP": m["AP_0.5"],
            "RI": m["RI"], "mIoU_global": m["mIoU"],
            "pc_mIoU": pc,
            "n_pred_inst": n_pred_inst, "n_gt_inst": n_gt_inst,
            "n_pts": n_pts_used, "n_clustered": n_clustered,
            "latency_ms": (t1 - t0) * 1000.0}


# ═══════════════════════════════════════════════════════════════
# Main
# ═══════════════════════════════════════════════════════════════

def main():
    import yaml
    cfg = yaml.safe_load(open(os.path.join(SCRIPT_DIR, "config.yaml"), 'r'))

    seq = cfg.get("sequence", "08")
    data_root = cfg.get("data_root",
                        "/media/lxcd/c8633166-003f-40ae-8230-3576dcc4963e/semantickitti/data")

    v_dir = os.path.join(data_root, "velodyne", seq, "velodyne")
    l_dir = os.path.join(data_root, "labels", seq, "labels")
    if not os.path.exists(v_dir):
        v_dir = os.path.join(data_root, "velodyne", seq)
        l_dir = os.path.join(data_root, "labels", seq)

    if not os.path.exists(v_dir):
        print(f"❌ 数据不存在: {data_root}")
        return

    # 命令行参数: python ablation_study.py [data_root] [seq] [n_frames]
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    if len(args) >= 1:
        data_root = args[0]
        v_dir = os.path.join(data_root, "velodyne", seq, "velodyne")
        l_dir = os.path.join(data_root, "labels", seq, "labels")
        if not os.path.exists(v_dir):
            v_dir = os.path.join(data_root, "velodyne", seq)
            l_dir = os.path.join(data_root, "labels", seq)
    if len(args) >= 2:
        seq = str(args[1]).zfill(2)
        v_dir = os.path.join(data_root, "velodyne", seq, "velodyne")
        l_dir = os.path.join(data_root, "labels", seq, "labels")
        if not os.path.exists(v_dir):
            v_dir = os.path.join(data_root, "velodyne", seq)
            l_dir = os.path.join(data_root, "labels", seq)

    frames_all = sorted([f for f in os.listdir(v_dir) if f.endswith('.bin')])
    if len(args) >= 3:
        n_frames = min(int(args[2]), len(frames_all))
    else:
        n_frames = len(frames_all)
    frames = frames_all[:n_frames]

    # 参数: 全部从 config.yaml 读取, 与 main.py 完全一致
    params = {
        "voxel_size":            cfg.get("voxel_size", 0.08),
        "ground_dist_threshold": cfg.get("ground_dist_threshold", 0.24),
        "eps_base":              cfg.get("eps_base", 0.62),
        "min_samples":           cfg.get("min_samples", 8),
        "sensitivity":           cfg.get("sensitivity", 2.23),
        "min_cluster_size":      cfg.get("min_cluster_size", 13),
        "intensity_weight":      cfg.get("intensity_weight", 0.15),
    }

    first_lbl = os.path.join(l_dir, frames[0].replace('.bin', '.label'))
    detect_label_encoding(first_lbl)

    print(f"📦 序列 {seq}: {n_frames}/{len(frames_all)} 帧")
    print("🎯 参数 (来自 config.yaml):")
    for k, v in params.items():
        print(f"    {k}: {v}")
    print()

    # ═══════════════════════════════════════════════════════════
    # 逐变体评估
    # ═══════════════════════════════════════════════════════════
    summary = []

    for ab in ABLATIONS:
        label = ab["short"]
        print(f"{'='*60}\n🔬 {ab['name']}\n{'='*60}")

        metrics_list = []
        debug_done = False
        for fn in tqdm(frames, desc=f"  {label}"):
            lbl_path = os.path.join(l_dir, fn.replace(".bin", ".label"))
            if not os.path.exists(lbl_path):
                continue
            r = run_frame(os.path.join(v_dir, fn), lbl_path,
                          ab, params, debug=(not debug_done))
            if not debug_done and r is not None:
                debug_done = True
            if r is not None:
                metrics_list.append(r)

        if not metrics_list:
            print(f"  ⚠️ 无有效帧")
            summary.append({"variant": ab["name"], "short": ab["short"],
                            "pc_macro": np.nan, "mIoU_global": np.nan,
                            "HV": np.nan, "F1": np.nan, "AP": np.nan, "RI": np.nan,
                            "pc": {}, "n_frames": 0, "color": ab["color"],
                            "n_pred_inst": 0, "n_gt_inst": 0,
                            "n_clustered": 0, "clustered_pct": 0})
            continue

        # 聚合指标
        miou_global = np.mean([x["mIoU_global"] for x in metrics_list])
        f1          = np.mean([x["F1"]          for x in metrics_list])
        ap          = np.mean([x["AP"]          for x in metrics_list])
        ri          = np.mean([x["RI"]          for x in metrics_list])
        hv          = (f1 * miou_global * ap * ri) ** 0.25 if all(
            v > 0 for v in [f1, miou_global, ap, ri]) else np.nan

        # 逐类 mIoU
        pc_means = {}
        for cn in CLASS_NAMES:
            vals = [x["pc_mIoU"][cn] for x in metrics_list
                    if not np.isnan(x["pc_mIoU"].get(cn, np.nan))]
            pc_means[cn] = np.mean(vals) if vals else np.nan
        pc_macro = np.nanmean(list(pc_means.values()))

        # 统计量
        avg_pred_inst = np.mean([x["n_pred_inst"] for x in metrics_list])
        avg_gt_inst   = np.mean([x["n_gt_inst"]   for x in metrics_list])
        avg_clustered = np.mean([x["n_clustered"]  for x in metrics_list])
        clustered_pct = np.mean([x["n_clustered"] / max(x["n_pts"], 1) * 100
                                 for x in metrics_list])

        print(f"  🎯 Per-Class Macro mIoU = {pc_macro:.4f}  "
              f"(全局 mIoU={miou_global:.4f}, F1={f1:.4f})")
        print(f"  📊 pred_inst={avg_pred_inst:.1f} | gt_inst={avg_gt_inst:.1f} | "
              f"clustered={avg_clustered:.0f} ({clustered_pct:.0f}%)")
        print(f"  📋 Per-class: " + " | ".join(
            f"{cn}={pc_means[cn]:.4f}" if not np.isnan(pc_means[cn]) else f"{cn}=—"
            for cn in CLASS_NAMES))

        summary.append({"variant": ab["name"], "short": ab["short"],
                        "pc_macro": pc_macro, "mIoU_global": miou_global,
                        "HV": hv, "F1": f1, "AP": ap, "RI": ri,
                        "pc": pc_means, "n_frames": len(metrics_list),
                        "color": ab["color"],
                        "n_pred_inst": avg_pred_inst, "n_gt_inst": avg_gt_inst,
                        "n_clustered": avg_clustered, "clustered_pct": clustered_pct})

    # ═══════════════════════════════════════════════════════════
    # CSV 输出
    # ═══════════════════════════════════════════════════════════
    csv_rows = []
    for s in summary:
        row = {"variant": s["variant"],
               "PerClass_mIoU": s["pc_macro"],
               "mIoU_global": s["mIoU_global"],
               "HV": s["HV"], "F1": s["F1"],
               "AP": s["AP"], "RI": s["RI"],
               "n_pred_inst": s["n_pred_inst"],
               "n_gt_inst": s["n_gt_inst"],
               "n_clustered": s["n_clustered"],
               "clustered%": s["clustered_pct"],
               "n_frames": s["n_frames"]}
        for cn in CLASS_NAMES:
            row[f"mIoU_{cn}"] = s["pc"].get(cn, np.nan)
        csv_rows.append(row)
    pd.DataFrame(csv_rows).to_csv(os.path.join(PLOT_DIR, "ablation_results.csv"),
                                  index=False, encoding="utf-8-sig")

    # ═══════════════════════════════════════════════════════════
    # 终端汇总
    # ═══════════════════════════════════════════════════════════
    print(f"\n{'='*100}")
    print(f"📋 加法消融总结 — Per-Class mIoU (宏平均)")
    print(f"{'='*100}")
    print(f"  {'Variant':<28s} {'PerClass↑':>10s} {'Δ':>10s} "
          f"{'全局mIoU':>10s} {'F1':>10s} {'AP':>10s} {'RI':>10s}")
    print(f"  {'-'*28} {'-'*10} {'-'*10} {'-'*10} {'-'*10} {'-'*10} {'-'*10}")

    for i, s in enumerate(summary):
        pc = s["pc_macro"]
        mg = s["mIoU_global"]
        f1 = s["F1"]

        if i == 0:
            d_str = "  (base)"
        else:
            prev_pc = summary[i - 1]["pc_macro"]
            d = pc - prev_pc if (not np.isnan(pc) and not np.isnan(prev_pc)) else np.nan
            d_str = (f"+{d:.4f}" if (not np.isnan(d) and d > 0.0001)
                     else f"{d:.4f}" if not np.isnan(d) else "N/A")

        pc_str = f"{pc:.4f}" if not np.isnan(pc) else "N/A"
        mg_str = f"{mg:.4f}" if not np.isnan(mg) else "N/A"
        f1_str = f"{f1:.4f}" if not np.isnan(f1) else "N/A"
        print(f"  {s['variant']:<28s} {pc_str:>10s} {d_str:>10s} "
              f"{mg_str:>10s} {f1_str:>10s}")

    if (not np.isnan(summary[0]["pc_macro"]) and not np.isnan(summary[-1]["pc_macro"])):
        total_gain = summary[-1]["pc_macro"] - summary[0]["pc_macro"]
        print(f"\n  📈 Raw DBSCAN → Full 总增益: +{total_gain:.4f} (Per-Class macro mIoU)")

    # ═══════════════════════════════════════════════════════════
    # 逐类汇总
    # ═══════════════════════════════════════════════════════════
    print(f"\n{'='*100}")
    print(f"📋 消融实验 — 逐类 mIoU")
    print(f"{'='*100}")
    header = f"  {'Variant':<28s}"
    for cn in CLASS_NAMES:
        header += f" {cn:>10s}"
    print(header)
    print("  " + "-" * (28 + 10 * len(CLASS_NAMES)))
    for s in summary:
        row = f"  {s['variant']:<28s}"
        for cn in CLASS_NAMES:
            v = s["pc"].get(cn, np.nan)
            row += f" {v:10.4f}" if not np.isnan(v) else f" {'—':>10s}"
        print(row)

    # ═══════════════════════════════════════════════════════════
    # 图1: 逐类 mIoU 热力图
    # ═══════════════════════════════════════════════════════════
    valid_sum = [s for s in summary if not np.isnan(s["pc_macro"])]
    hm = np.array([[s["pc"].get(cn, np.nan) for cn in CLASS_NAMES] for s in valid_sum])
    fig, ax = plt.subplots(figsize=(14, 3.5 + 0.4 * len(valid_sum)))
    im = ax.imshow(hm, cmap="RdYlGn", aspect="auto", vmin=0, vmax=0.6)
    ax.set_xticks(np.arange(len(CLASS_NAMES)))
    ax.set_xticklabels(CLASS_NAMES, fontsize=10, rotation=30)
    ax.set_yticks(np.arange(len(valid_sum)))
    ax.set_yticklabels([s["short"] for s in valid_sum], fontsize=10)
    for i in range(len(valid_sum)):
        for j in range(len(CLASS_NAMES)):
            v = hm[i, j]
            t = f"{v:.3f}" if not np.isnan(v) else "—"
            ax.text(j, i, t, ha="center", va="center", fontsize=8, fontweight="bold",
                    color="white" if (not np.isnan(v) and v < 0.3) else "black")
    ax.set_title("Additive Ablation — Per-Class mIoU Heatmap", fontweight="bold", fontsize=14)
    plt.colorbar(im, ax=ax, shrink=0.8).set_label("mIoU", fontweight="bold")
    fig.tight_layout()
    fig.savefig(os.path.join(PLOT_DIR, "ablation_per_class_heatmap.png"), dpi=200, bbox_inches="tight")
    plt.close(fig)

    # ═══════════════════════════════════════════════════════════
    # 图2: 小目标柱状图
    # ═══════════════════════════════════════════════════════════
    small_classes = ["Bicycle", "Motorcycle", "Person", "Bicyclist", "Motorcyclist"]
    fig, ax = plt.subplots(figsize=(12, 5.5))
    x = np.arange(len(small_classes))
    w = 0.14
    for vi, s in enumerate(valid_sum):
        vals = [s["pc"].get(cn, 0) for cn in small_classes]
        off = (vi - len(valid_sum) / 2 + 0.5) * w
        ax.bar(x + off, [v if not np.isnan(v) else 0 for v in vals], w,
               color=s["color"], edgecolor="white", linewidth=0.5, label=s["short"])
    ax.set_xticks(x)
    ax.set_xticklabels(small_classes, fontsize=11)
    ax.set_ylabel("mIoU", fontweight="bold", fontsize=13)
    ax.set_title("Additive Ablation — Small-Object Per-Class mIoU", fontweight="bold", fontsize=14)
    ax.legend(fontsize=8, ncol=3)
    ax.grid(axis="y", alpha=0.3)
    fig.tight_layout()
    fig.savefig(os.path.join(PLOT_DIR, "ablation_small_objects.png"), dpi=200, bbox_inches="tight")
    plt.close(fig)

    # ═══════════════════════════════════════════════════════════
    # 图3: Per-Class + 全局 mIoU 双柱图
    # ═══════════════════════════════════════════════════════════
    fig, ax = plt.subplots(figsize=(14, 6))
    x = np.arange(len(valid_sum))
    w = 0.35
    ax.bar(x - w/2, [s["pc_macro"] for s in valid_sum], w,
           color=[s["color"] for s in valid_sum],
           edgecolor="white", linewidth=1, label="Per-Class Macro mIoU")
    ax.bar(x + w/2, [s["mIoU_global"] for s in valid_sum], w,
           color=[s["color"] for s in valid_sum], alpha=0.4,
           edgecolor="white", linewidth=1, label="Global mIoU (Hungarian)")
    ax.set_xticks(x)
    ax.set_xticklabels([s["short"] for s in valid_sum], fontsize=9, rotation=20)
    ax.set_ylabel("Score", fontweight="bold", fontsize=13)
    ax.set_title("Additive Ablation — Per-Class Macro mIoU & Global mIoU\n"
                 "(components added left → right, +PCA = Full = main.py ipdbscan_adaptive_xyz)",
                 fontweight="bold", fontsize=14)
    ax.legend(fontsize=10)
    ax.grid(axis="y", alpha=0.3)
    fig.tight_layout()
    fig.savefig(os.path.join(PLOT_DIR, "ablation_miou_hv.png"), dpi=200, bbox_inches="tight")
    plt.close(fig)

    # ═══════════════════════════════════════════════════════════
    # 图4: 消融增益瀑布图
    # ═══════════════════════════════════════════════════════════
    fig, ax = plt.subplots(figsize=(14, 5))
    vals = [s["pc_macro"] for s in valid_sum]
    labels = [s["short"] for s in valid_sum]
    colors = [s["color"] for s in valid_sum]
    ax.plot(range(len(vals)), vals, 'o-', color='#333', linewidth=2, markersize=8)
    for i, (v, c) in enumerate(zip(vals, colors)):
        ax.plot(i, v, 'o', color=c, markersize=12, markeredgecolor='white', markeredgewidth=1.5)
    for i in range(1, len(vals)):
        if not np.isnan(vals[i]) and not np.isnan(vals[i-1]):
            delta = vals[i] - vals[i-1]
            mid_y = (vals[i] + vals[i-1]) / 2
            sign = "+" if delta >= 0 else ""
            ax.annotate(f"{sign}{delta:.3f}", xy=(i - 0.45, mid_y),
                        fontsize=8, ha='center', va='bottom' if delta >= 0 else 'top',
                        color='#2ECC40' if delta >= 0 else '#E74C3C', fontweight='bold')
    ax.set_xticks(range(len(labels)))
    ax.set_xticklabels(labels, fontsize=9, rotation=20)
    ax.set_ylabel("Per-Class Macro mIoU", fontweight="bold", fontsize=13)
    ax.set_title("Ablation Waterfall — Per-Class mIoU Gain per Component",
                 fontweight="bold", fontsize=14)
    ax.grid(axis="y", alpha=0.3)
    fig.tight_layout()
    fig.savefig(os.path.join(PLOT_DIR, "ablation_waterfall.png"), dpi=200, bbox_inches="tight")
    plt.close(fig)

    print(f"\n✅ {PLOT_DIR}/")
    print("   ablation_results.csv              (完整数据)")
    print("   ablation_per_class_heatmap.png     (逐类 mIoU 热力图)")
    print("   ablation_small_objects.png         (小目标逐类对比)")
    print("   ablation_miou_hv.png               (Per-Class + 全局 mIoU)")
    print("   ablation_waterfall.png             (组件增益瀑布图)")
    print(f"\n📐 消融链: {' → '.join([ab['short'] for ab in ABLATIONS])}")
    print(f"   (+PCA = Full v13 = main.py 完整流水线)")


if __name__ == "__main__":
    main()
