﻿"""
main.py — v13 论文评估脚本 08序列
1. 预处理: core.preprocess -> remove_ground_grid
2. 聚类: core.ipdbscan_fusion -> ipdbscan_adaptive_xyz
3. 评估: utils.metrics -> compute_metrics
参数从 config.yaml 读取
"""
import os, time, yaml
import numpy as np, pandas as pd
from scipy.spatial import cKDTree
from tqdm import tqdm

from core.preprocess import load_kitti_bin, remove_ground_grid
from core.ipdbscan_fusion import ipdbscan_adaptive_xyz
from utils.metrics import compute_metrics

DATA_ROOT = "/media/lxcd/c8633166-003f-40ae-8230-3576dcc4963e/semantickitti/data"

def main():
    # 读取配置
    cfg = yaml.safe_load(open("config.yaml", 'r'))

    print("🚀 IPDBSCAN v13...")
    seq = cfg.get("sequence", "08")
    v_dir = os.path.join(cfg.get("data_root", DATA_ROOT), "velodyne", seq, "velodyne")
    l_dir = os.path.join(cfg.get("data_root", DATA_ROOT), "labels", seq, "labels")

    if not os.path.exists(v_dir):
        v_dir = os.path.join(cfg.get("data_root", DATA_ROOT), "velodyne", seq)
        l_dir = os.path.join(cfg.get("data_root", DATA_ROOT), "labels", seq)

    frames = sorted([f for f in os.listdir(v_dir) if f.endswith('.bin')])
    print(f"📦 序列 {seq}: 共 {len(frames)} 帧")

    # 从 config 读取参数
    voxel_size     = cfg.get("voxel_size", 0.08)
    dist_thresh    = cfg.get("ground_dist_threshold", 0.24)
    sensitivity    = cfg.get("sensitivity", 2.23)
    eps_base       = cfg.get("eps_base", 0.62)
    min_samples    = cfg.get("min_samples", 8)
    min_cluster_size = cfg.get("min_cluster_size", 13)
    intensity_weight = cfg.get("intensity_weight", 0.15)
    print(f"  config: eps_base={eps_base} min_samples={min_samples} "
          f"min_cluster_size={min_cluster_size} sensitivity={sensitivity}")

    results = []

    for f_name in tqdm(frames, desc="评估中"):
        bin_path = os.path.join(v_dir, f_name)
        pc_raw = load_kitti_bin(bin_path)

        t_start = time.perf_counter()

        # 1. 预处理
        pts, imat = remove_ground_grid(pc_raw, voxel_size=voxel_size,
                                          ground_z_thresh=dist_thresh)
        ints = imat.ravel() if len(imat) > 0 else None

        # 2. 核心自适应聚类
        if pts.shape[0] >= 10:
            labels_pred, eps_used = ipdbscan_adaptive_xyz(
                pts,
                sensitivity=sensitivity,
                eps_base=eps_base,
                min_samples=min_samples,
                min_cluster_size=min_cluster_size,
                intensity_weight=intensity_weight,
                intensity=ints)
        else:
            labels_pred, eps_used = np.array([]), 0.0

        t_end = time.perf_counter()

        if pts.shape[0] < 10:
            continue

        latency_ms = (t_end - t_start) * 1000.0
        fps = 1.0 / (t_end - t_start)

        # 3. 对齐标签与评估
        lbl_path = os.path.join(l_dir, f_name.replace('.bin', '.label'))
        if not os.path.exists(lbl_path):
            continue

        gt_inst = (np.fromfile(lbl_path, dtype=np.uint32) >> 16)
        tree_gt = cKDTree(pc_raw[:, :3])
        _, n_idx = tree_gt.query(pts, k=1)
        gt_aligned = gt_inst[n_idx]

        if np.sum(gt_aligned > 0) < 10:
            continue

        m = compute_metrics(pts, labels_pred, gt_aligned)
        m.update({
            'frame': f_name,
            'eps_used': eps_used,
            'latency_ms': latency_ms,
            'FPS': fps
        })
        results.append(m)

    if not results:
        print("❌ 无有效数据"); return

    df = pd.DataFrame(results)
    os.makedirs(cfg.get("result_dir", "results"), exist_ok=True)
    df.to_csv(f"{cfg.get('result_dir', 'results')}/final_paper_metrics.csv", index=False)

    print("\n========================================================")
    print("🏆 IPDBSCAN v13 指标报告")
    print("========================================================")
    print(f" 🎯 实例检测 → F1: {df['F1_Score'].mean():.4f} | P: {df['Precision'].mean():.4f} | R: {df['Recall'].mean():.4f}")
    print(f" 🎯 AP@0.5: {df['AP_0.5'].mean():.4f} | mIoU: {df['mIoU'].mean():.4f} | RI: {df['RI'].mean():.4f}")
    print(f" 🎯 n_pred: {df['n_pred'].mean():.1f} | n_true: {df['n_true'].mean():.1f}")
    print(f" ⚡ 耗时: {df['latency_ms'].mean():.0f}ms | FPS: {df['FPS'].mean():.1f}")
    print("========================================================")

if __name__ == "__main__":
    main()
