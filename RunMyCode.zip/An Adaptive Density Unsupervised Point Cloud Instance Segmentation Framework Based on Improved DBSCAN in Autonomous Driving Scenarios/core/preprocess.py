"""
预处理 — 网格法去地面 (v13配套)
"""
import numpy as np
import open3d as o3d


def load_kitti_bin(bin_path):
    points = np.fromfile(bin_path, dtype=np.float32).reshape(-1, 4)
    return points


def _grid_ground_removal(xyz, intensity, grid_size=2.0,
                          ground_z_thresh=0.25,
                          min_points_per_cell=8,
                          ground_percentile=15):
    n = xyz.shape[0]
    x_min, y_min = xyz[:, 0].min(), xyz[:, 1].min()
    col = np.floor((xyz[:, 0] - x_min) / grid_size).astype(np.int32)
    row = np.floor((xyz[:, 1] - y_min) / grid_size).astype(np.int32)
    grid_key = col * 10000 + row

    unique_grids = np.unique(grid_key)
    grid_ground_z = {}
    for gk in unique_grids:
        mask = grid_key == gk
        n_cell = np.sum(mask)
        if n_cell < min_points_per_cell:
            continue
        grid_ground_z[gk] = np.percentile(xyz[mask, 2], ground_percentile)

    if len(grid_ground_z) == 0:
        return xyz, intensity

    all_grids = np.array(list(grid_ground_z.keys()))
    all_zs = np.array(list(grid_ground_z.values()))
    is_ground = np.zeros(n, dtype=bool)
    assigned = np.zeros(n, dtype=bool)

    for gk, gz in grid_ground_z.items():
        mask = grid_key == gk
        is_ground[mask] = (xyz[mask, 2] < gz + ground_z_thresh)
        assigned[mask] = True

    unassigned = ~assigned
    if np.any(unassigned):
        from scipy.spatial import cKDTree
        grid_centers = np.column_stack([
            (all_grids // 10000) * grid_size + x_min + grid_size / 2,
            (all_grids % 10000) * grid_size + y_min + grid_size / 2,
        ])
        tree = cKDTree(grid_centers)
        for i in np.where(unassigned)[0]:
            _, idx = tree.query([xyz[i, 0], xyz[i, 1]], k=1)
            is_ground[i] = (xyz[i, 2] < all_zs[idx] + ground_z_thresh)

    return xyz[~is_ground], intensity[~is_ground]


def remove_ground_grid(points, voxel_size=0.15, grid_size=2.0,
                          ground_z_thresh=0.25, **kwargs):
    if points.shape[0] < 10:
        return np.zeros((0, 3)), np.zeros((0, 1))

    xyz = points[:, :3]
    intensity = points[:, 3].reshape(-1, 1)

    pcd = o3d.geometry.PointCloud()
    pcd.points = o3d.utility.Vector3dVector(xyz)
    pcd.colors = o3d.utility.Vector3dVector(np.hstack([intensity]*3))
    pcd_down = pcd.voxel_down_sample(voxel_size)

    xyz_down = np.asarray(pcd_down.points)
    ints_down = np.asarray(pcd_down.colors)[:, 0]

    xyz_ng, ints_ng = _grid_ground_removal(
        xyz_down, ints_down, grid_size=grid_size,
        ground_z_thresh=ground_z_thresh)

    if len(xyz_ng) == 0:
        return np.zeros((0, 3)), np.zeros((0, 1))

    roi_mask = ((xyz_ng[:, 0] > 0.0) & (xyz_ng[:, 0] < 45) &
                (np.abs(xyz_ng[:, 1]) < 20) & (xyz_ng[:, 2] > -2.0))
    return xyz_ng[roi_mask], ints_ng[roi_mask].reshape(-1, 1)


def remove_ground_grid_fullres(points, **kwargs):
    if points.shape[0] < 10:
        return points
    xyz = points[:, :3]
    intensity = points[:, 3]
    xyz_ng, ints_ng = _grid_ground_removal(
        xyz, intensity,
        grid_size=kwargs.get('grid_size', 2.0),
        ground_z_thresh=kwargs.get('ground_z_thresh', 0.25))
    return np.column_stack([xyz_ng, ints_ng]) if len(xyz_ng) > 0 else points[:0]
