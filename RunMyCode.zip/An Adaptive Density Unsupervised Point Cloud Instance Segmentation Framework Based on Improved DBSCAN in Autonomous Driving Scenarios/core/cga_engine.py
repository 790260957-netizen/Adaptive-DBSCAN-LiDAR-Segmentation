import numpy as np
import open3d as o3d


def extract_cga_features(points, labels=None, radius=0.6):
    """
    Geometry-aware per-point feature extractor (label-free version).

    Returns a 14-dim geometric descriptor per point:
      [normal(3), local_normal_mean(3), curvature, local_density,
       relative_elevation, dist_to_center, radius_knn_mean,
       radius_knn_std, verticality, planarity, scattering]

    The `labels` parameter is kept for backward compatibility but IGNORED
    — CGA should NOT depend on semantic/instance labels at inference time,
    otherwise it prevents DBSCAN from separating same-class instances.
    """
    num_points = len(points)
    pcd = o3d.geometry.PointCloud()
    pcd.points = o3d.utility.Vector3dVector(points)
    pcd.estimate_normals(o3d.geometry.KDTreeSearchParamHybrid(radius=radius, max_nn=30))
    normals = np.asarray(pcd.normals)
    tree = o3d.geometry.KDTreeFlann(pcd)

    # local elevation / centroid context
    centroid_xy = points[:, :2].mean(axis=0)
    all_dists_xy = np.linalg.norm(points[:, :2] - centroid_xy, axis=1)
    median_dist_xy = np.median(all_dists_xy)
    elevations = points[:, 2]

    # output: compact geometric descriptor (14 dimensions)
    feat_dim = 14
    cga_feat = np.zeros((num_points, feat_dim), dtype=np.float32)

    for i in range(num_points):
        [k, idx, dists] = tree.search_radius_vector_3d(pcd.points[i], radius)
        if k <= 2:
            cga_feat[i, :3] = normals[i]
            cga_feat[i, 3] = 1.0  # curvature ~1 (no neighbors = sharp)
            continue

        idx = np.array([int(x) for x in idx], dtype=np.int64)
        dists = np.array([float(x) for x in dists], dtype=np.float64)

        # ---- neighbor geometric stats ----
        neighbor_normals = normals[idx]      # [k, 3]
        neighbor_xyz = points[idx]           # [k, 3]
        neighbor_z = neighbor_xyz[:, 2]

        # local normal mean + curvature
        local_norm_mean = neighbor_normals.mean(axis=0)
        local_norm_mean /= np.linalg.norm(local_norm_mean) + 1e-8
        curvature = 1.0 - abs(np.dot(normals[i], local_norm_mean))

        # local density (neighbors per unit volume)
        # sphere volume = 4/3 * pi * R³; density = k / volume
        sphere_vol = (4.0 / 3.0) * np.pi * max(radius, 0.1) ** 3
        local_density = min(k / sphere_vol, 100.0)  # cap

        # relative elevation
        relative_elevation = elevations[i] - np.median(neighbor_z)

        # distance to scene center (radial context)
        dist_to_center = np.linalg.norm(points[i, :2] - centroid_xy) / (median_dist_xy + 1e-8)

        # neighbor distance stats
        radius_knn_mean = dists.mean()
        radius_knn_std = dists.std()

        # verticality / planarity / scattering (eigenvalue-based)
        centered = neighbor_xyz - neighbor_xyz.mean(axis=0)
        cov = (centered.T @ centered) / (k - 1) if k > 1 else np.eye(3)
        eigenvalues, _ = np.linalg.eigh(cov)
        eigenvalues = np.sort(eigenvalues)[::-1]  # descending
        e_sum = eigenvalues.sum() + 1e-10
        lambda1, lambda2, lambda3 = eigenvalues / e_sum
        # verticality: how dominant is the vertical direction
        verticality = 1.0 - lambda3
        # planarity: (λ2 - λ3) / λ1
        planarity = (lambda2 - lambda3) / (lambda1 + 1e-10)
        # scattering: λ3 / λ1
        scattering = lambda3 / (lambda1 + 1e-10)

        cga_feat[i] = [
            normals[i, 0], normals[i, 1], normals[i, 2],
            curvature,
            local_density,
            relative_elevation,
            dist_to_center,
            radius_knn_mean,
            radius_knn_std,
            verticality,
            planarity,
            scattering,
            local_norm_mean[0], local_norm_mean[1],
        ]

    return cga_feat
