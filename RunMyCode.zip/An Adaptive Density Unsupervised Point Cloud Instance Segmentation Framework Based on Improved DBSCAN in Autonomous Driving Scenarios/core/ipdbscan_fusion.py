"""
v13 + 两步实例融合
==================
DBSCAN → 贪心合并 → PCA过滤 → 去小簇
"""
import numpy as np
from sklearn.cluster import DBSCAN
from sklearn.neighbors import NearestNeighbors
from scipy.spatial import cKDTree


def _greedy_merge(points, labels, merge_dist=1.0, max_merge_dist=2.5):
    labels = labels.copy()
    ct = merge_dist
    while ct <= max_merge_dist:
        uids = np.unique(labels[labels >= 0])
        if len(uids) <= 1: break
        centroids = np.array([points[labels == u].mean(axis=0) for u in uids])
        pairs = cKDTree(centroids).query_pairs(ct, output_type='ndarray')
        if len(pairs) == 0:
            ct += 0.5; continue
        parent = {u: u for u in uids}
        def find(x):
            while parent[x] != x:
                parent[x] = parent[parent[x]]
                x = parent[x]
            return x
        def union(a, b):
            ra, rb = find(a), find(b)
            if ra != rb: parent[rb] = ra
        for i, j in pairs: union(uids[i], uids[j])
        root = {}
        for u in uids:
            r = find(u)
            if r not in root: root[r] = len(root)
            labels[labels == u] = root[r]
        ct += 0.5
    valid = labels >= 0
    if np.any(valid):
        _, labels[valid] = np.unique(labels[valid], return_inverse=True)
    return labels


def _filter_background(points, labels):
    """PCA 物理过滤: 删墙/杆/球/矮"""
    labels = labels.copy()
    for uid in np.unique(labels[labels >= 0]):
        mask = labels == uid
        pts = points[mask]
        n = len(pts)
        if n < 5: labels[mask] = -1; continue

        z_span = pts[:, 2].max() - pts[:, 2].min()
        if z_span < 0.3: labels[mask] = -1; continue
        if z_span > 1.5 and n < 50: labels[mask] = -1; continue

        centered = pts - pts.mean(axis=0)
        eig = np.sort(np.linalg.eigh(centered.T @ centered / (n-1))[0])[::-1]
        esum = eig.sum() + 1e-10
        l1, l2, l3 = eig / esum
        planarity = (l2 - l3) / (l1 + 1e-10)
        linearity = (l1 - l2) / (l1 + 1e-10)
        sphericity = l3

        if planarity > 0.75: labels[mask] = -1
        elif linearity > 0.95: labels[mask] = -1
        elif sphericity > 0.45: labels[mask] = -1

    valid = labels >= 0
    if np.any(valid):
        _, labels[valid] = np.unique(labels[valid], return_inverse=True)
    return labels, len(np.unique(labels[labels >= 0]))


def _adaptive_eps_from_knee(feats, min_samples=10, sensitivity=1.0):
    k = min_samples - 1
    if k < 1 or feats.shape[0] <= k + 1: return 0.5
    nn = NearestNeighbors(n_neighbors=k + 1, n_jobs=-1).fit(feats)
    distances, _ = nn.kneighbors(feats)
    k_dist = np.sort(distances[:, k]); k_dist = k_dist[k_dist > 0]
    if len(k_dist) < 5: return float(np.median(k_dist))
    x = np.arange(len(k_dist)) / (len(k_dist) - 1)
    y = (k_dist - k_dist[0]) / (k_dist[-1] - k_dist[0] + 1e-10)
    return max(float(k_dist[int(np.argmax(np.abs(y - x)))]) * sensitivity, 0.05)


def ipdbscan_adaptive_xyz(points, sensitivity=2.0, min_samples=10,
                           merge_dist=1.0, max_merge_dist=3.0,
                           min_cluster_size=20,
                           intensity=None, intensity_weight=0.0,
                           **kwargs):
    """
    v13: DBSCAN → merge → PCA过滤 → 去小簇
    """
    n = len(points)
    if n < min_samples:
        return np.full(n, -1, dtype=int), 0.0

    feats = points.astype(np.float64)
    if intensity is not None and intensity_weight > 0:
        ints = intensity.reshape(-1) if intensity.ndim > 1 else intensity
        feats = np.column_stack([feats, ints * intensity_weight])

    eps = _adaptive_eps_from_knee(feats, min_samples=min_samples,
                                   sensitivity=sensitivity)
    labels = DBSCAN(eps=eps, min_samples=min_samples, n_jobs=-1).fit_predict(feats)
    n1 = len(np.unique(labels[labels >= 0]))

    if n1 > 1:
        labels = _greedy_merge(points, labels, merge_dist=merge_dist,
                                max_merge_dist=max_merge_dist)

    labels, n2 = _filter_background(points, labels)

    uids, counts = np.unique(labels[labels >= 0], return_counts=True)
    for u in uids[counts < min_cluster_size]:
        labels[labels == u] = -1
    valid = labels >= 0
    if np.any(valid):
        _, labels[valid] = np.unique(labels[valid], return_inverse=True)

    n_final = len(np.unique(labels[labels >= 0]))
    n_clust = int(np.sum(labels != -1))
    print(f"  [v13] eps={eps:.3f} "
          f"dbscan→{n1}c pca→{n2}c →{n_final}c "
          f"({n_clust}/{n} pts)")

    return labels, eps


def improved_dbscan(xyz, base_eps=0.5, min_samples=5):
    """Zone-based IPDBSCAN (保留)."""
    num_points = xyz.shape[0]
    final_labels = np.full(num_points, -1, dtype=int)
    if num_points == 0:
        return final_labels
    distances = np.linalg.norm(xyz[:, :2], axis=1)
    zones = [
        {'min_r': 0, 'max_r': 20, 'eps_multiplier': 1.0},
        {'min_r': 20, 'max_r': 40, 'eps_multiplier': 1.5},
        {'min_r': 40, 'max_r': 80, 'eps_multiplier': 2.5}
    ]
    max_label_id = 0
    for zone in zones:
        mask = (distances >= zone['min_r']) & (distances < zone['max_r'])
        if not np.any(mask): continue
        zone_points = xyz[mask]
        adaptive_eps = base_eps * zone['eps_multiplier']
        clustering = DBSCAN(eps=adaptive_eps, min_samples=min_samples, n_jobs=-1)
        zone_labels = clustering.fit_predict(zone_points)
        valid = zone_labels != -1
        if np.any(valid):
            zone_labels[valid] += max_label_id
            max_label_id = np.max(zone_labels[valid]) + 1
        final_labels[mask] = zone_labels
    return final_labels


def ipdbscan_fusion(points, cga_feats, deep_feats, alpha=0.6, eps_base=0.8, min_samples=6):
    """CGA+deep fusion (保留)."""
    from sklearn.neighbors import NearestNeighbors
    from sklearn.preprocessing import StandardScaler

    num_points = points.shape[0]
    if len(deep_feats.shape) == 1:
        deep_feats = np.tile(deep_feats, (num_points, 1))
    cga_norm = StandardScaler().fit_transform(cga_feats)
    deep_norm = StandardScaler().fit_transform(deep_feats)
    if cga_norm.shape[1] >= 5:
        curvature, density = np.abs(cga_norm[:, 3]), np.clip(cga_norm[:, 4], 0, 1)
        w_geo = np.clip(curvature * density, 0.05, 0.95)
    else:
        r = np.linalg.norm(points[:, :2], axis=1)
        w_geo = 1.0 - np.clip(r / (np.percentile(r, 90) + 1e-8), 0.1, 1.0)
    w_geo = np.clip((w_geo * alpha + alpha) / 2.0, 0.1, 0.9).reshape(-1, 1)
    w_deep = 1.0 - w_geo
    f = np.hstack([cga_norm * w_geo, deep_norm * w_deep])
    k = min_samples - 1
    if k >= 1 and f.shape[0] > k + 1:
        nn = NearestNeighbors(n_neighbors=k + 1, n_jobs=-1).fit(f)
        d, _ = nn.kneighbors(f); kd = np.sort(d[:, k])
        pct = np.clip(eps_base * 60 + 30, 40, 95) if eps_base <= 10 else np.clip(eps_base, 20, 98)
        eps_final = max(float(kd[min(int(len(kd)*pct/100), len(kd)-1)]), 0.05)
    else:
        eps_final = eps_base * np.sqrt(f.shape[1] / 3.0)
    db = DBSCAN(eps=eps_final, min_samples=min_samples, n_jobs=-1).fit(f)
    return db.labels_
