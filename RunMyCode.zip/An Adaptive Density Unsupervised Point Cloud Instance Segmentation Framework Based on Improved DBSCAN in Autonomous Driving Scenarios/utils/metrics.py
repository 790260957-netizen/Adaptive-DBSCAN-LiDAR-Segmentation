# 文件路径：train2/utils/metrics.py
import numpy as np
from sklearn.metrics import adjusted_rand_score, normalized_mutual_info_score, rand_score


def compute_clustering_metrics(labels_true, labels_pred, bg_label_true=0, noise_label_pred=-1):
    valid_mask = (labels_true != bg_label_true) & (labels_pred != noise_label_pred)
    if np.sum(valid_mask) > 1:
        ari = adjusted_rand_score(labels_true[valid_mask], labels_pred[valid_mask])
        nmi = normalized_mutual_info_score(labels_true[valid_mask], labels_pred[valid_mask])
        ri = rand_score(labels_true[valid_mask], labels_pred[valid_mask])
    else:
        ari, nmi, ri = 0.0, 0.0, 0.0
    tp_mask = (labels_true != bg_label_true) & (labels_pred != noise_label_pred)
    tp = np.sum(tp_mask)
    fp_mask = (labels_true == bg_label_true) & (labels_pred != noise_label_pred)
    fp = np.sum(fp_mask)
    fn_mask = (labels_true != bg_label_true) & (labels_pred == noise_label_pred)
    fn = np.sum(fn_mask)
    precision = tp / (tp + fp) if (tp + fp) > 0 else 0.0
    recall = tp / (tp + fn) if (tp + fn) > 0 else 0.0
    f1 = 2 * (precision * recall) / (precision + recall) if (precision + recall) > 0 else 0.0
    return {'ARI': ari, 'NMI': nmi, 'RI': ri, 'Precision': precision, 'Recall': recall, 'F1_Score': f1}


def compute_metrics(points, labels_pred, labels_gt=None, iou_threshold=0.5):
    from sklearn import metrics as sk_metrics
    from scipy.optimize import linear_sum_assignment

    res = {
        'Precision': 0.0, 'Recall': 0.0, 'F1_Score': 0.0,
        'AP_0.5': 0.0, 'mIoU': 0.0, 'RI': 0.0,
        'n_pred': 0, 'n_true': 0,
    }

    if labels_gt is not None and len(labels_pred) != len(labels_gt):
        min_len = min(len(labels_pred), len(labels_gt))
        labels_pred = labels_pred[:min_len]
        labels_gt = labels_gt[:min_len]

    mask_pred_valid = (labels_pred != -1)
    n_clustered = int(np.sum(mask_pred_valid))
    if n_clustered < 5:
        return res

    if labels_gt is None:
        return res

    # 实例级 Detection
    unique_pred = np.unique(labels_pred[labels_pred >= 0])
    unique_true = np.unique(labels_gt[labels_gt > 0])
    res['n_pred'] = len(unique_pred)
    res['n_true'] = len(unique_true)

    if len(unique_pred) > 0 and len(unique_true) > 0:
        # ---- RI (Rand Index) — 仅前景+非噪声点 ----
        mask_valid = (labels_gt != 0) & (labels_pred != -1)
        if np.sum(mask_valid) > 1:
            res['RI'] = sk_metrics.rand_score(labels_gt[mask_valid], labels_pred[mask_valid])

        # 构建 IoU 矩阵
        iou_matrix = np.zeros((len(unique_pred), len(unique_true)))
        for p_idx, p_id in enumerate(unique_pred):
            mask_p = (labels_pred == p_id)
            for t_idx, t_id in enumerate(unique_true):
                mask_t = (labels_gt == t_id)
                inter = np.sum(mask_p & mask_t)
                union = np.sum(mask_p | mask_t)
                iou_matrix[p_idx, t_idx] = inter / union if union > 0 else 0.0

        # 匈牙利最优匹配
        row_idx, col_idx = linear_sum_assignment(-iou_matrix)
        matched_ious = iou_matrix[row_idx, col_idx]

        # ---- Precision / Recall / F1 (IoU >= 0.5) ----
        tp_count = int(np.sum(matched_ious >= iou_threshold))

        res['Precision'] = tp_count / len(unique_pred) if len(unique_pred) > 0 else 0.0
        res['Recall'] = tp_count / len(unique_true) if len(unique_true) > 0 else 0.0
        res['F1_Score'] = (
            2 * res['Precision'] * res['Recall'] /
            (res['Precision'] + res['Recall'])
        ) if (res['Precision'] + res['Recall']) > 0 else 0.0

        # ---- mIoU ----
        res['mIoU'] = float(np.mean(matched_ious))

        # ---- AP@0.5 (11-point interpolated) ----
        ious_sorted = np.sort(matched_ious)[::-1]
        precisions = np.cumsum(ious_sorted >= 0.5) / np.arange(1, len(ious_sorted) + 1)
        recalls = np.cumsum(ious_sorted >= 0.5) / len(unique_true)
        if len(precisions) > 0:
            ap = 0.0
            for t in np.linspace(0, 1, 11):
                if np.sum(recalls >= t) > 0:
                    ap += np.max(precisions[recalls >= t]) / 11.0
            res['AP_0.5'] = ap

    return res
