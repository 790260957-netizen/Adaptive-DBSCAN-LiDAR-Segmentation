﻿import os
import glob
import numpy as np
import torch
from torch.utils.data import Dataset
from core.preprocess import load_kitti_bin, remove_ground_grid

# SemanticKITTI 标准划分
SPLIT_MAP = {
    'train': ['00', '01', '02', '03', '04', '05', '06', '07', '09', '10'],
    'val':   ['08'],
    'test':  ['11', '12', '13', '14', '15', '16', '17', '18', '19', '20', '21'],
}


class SemanticKITTIDataset(Dataset):
    def __init__(self, data_root, split='train', npoints=4096):
        self.npoints = npoints

        # --- 递归搜索所有 .bin 文件 ---
        search_path = os.path.join(data_root, "**/*.bin")
        all_files = glob.glob(search_path, recursive=True)
        all_files.sort()

        # --- 按序列号过滤，确保 train/val/test 不泄露 ---
        seq_ids = SPLIT_MAP.get(split, SPLIT_MAP['train'])
        self.file_list = []
        for f in all_files:
            # 从路径中提取序列号（兼容 velodyne/XX/velodyne/ 和 velodyne/XX/ 结构）
            parts = f.replace('\\', '/').split('/')
            for i, p in enumerate(parts):
                if p == 'velodyne' and i + 1 < len(parts):
                    seq_candidate = parts[i + 1]
                    if seq_candidate.isdigit() and len(seq_candidate) == 2:
                        if seq_candidate in seq_ids:
                            self.file_list.append(f)
                        break

        if len(self.file_list) == 0:
            print(f"❌ 警告：在 {data_root} 中未找到 split='{split}' (序列 {seq_ids}) 的任何 .bin 文件！")
        else:
            print(f"✅ split='{split}' 成功加载 {len(self.file_list)} 个样本 (序列 {seq_ids})")

    def __len__(self):
        return len(self.file_list)

    def __getitem__(self, index):
        # 保持你原来的逻辑
        raw_data = load_kitti_bin(self.file_list[index])
        pts, ints = remove_ground_grid(raw_data, voxel_size=0.15, dist_thresh=0.2)

        combined = np.hstack([pts, ints])
        curr_n = combined.shape[0]

        # 统一采样点数给 PointNet++
        if curr_n >= self.npoints:
            choice = np.random.choice(curr_n, self.npoints, replace=False)
        else:
            choice = np.random.choice(curr_n, self.npoints, replace=True) if curr_n > 0 else np.zeros(self.npoints,
                                                                                                      dtype=int)

        combined = combined[choice, :] if curr_n > 0 else np.zeros((self.npoints, 4))
        return torch.from_numpy(combined).float().T, 0